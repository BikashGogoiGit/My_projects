<?php 
/**
 
 *
 * Create all Tables
 *
 * @package    iraqsoftserialmanagement
 * @subpackage iraqsoftserialmanagement/includes
 * @author     Abdul Ghafor Sabury <gh.sabury@gmail.com>
 */
if(!class_exists('Issmmigration')){
	class Issmmigration{
		/**
		 * hold wpd object
		 *
		 * @since    1.0.0
		 * @access   private
		 * @var      Object
		*/
		private $wpdb_object;
		/**
		 * hold table prefixes
		 *
		 * @since    1.0.0
		 * @access   private
		 * @var      string
		*/
		private $tbl_prefix;

		/**
		 * hold table charset
		 *
		 * @since    1.0.0
		 * @access   private
		 * @var      string
		*/
		private $charset_collate;

		/**
		 * Initialize the class and set its properties.
		 *
		 * @since    1.0.0
		 * @param      no param.
	 	*/
		function __construct(){
			global $wpdb;
			$this->wpdb_object =  $wpdb;
			$this->tbl_prefix = $this->wpdb_object->prefix;
			$this->charset_collate = $this->wpdb_object->get_charset_collate();
		}


		/**
		 * create serial table.
		 *
		 * @since 	1.0.0
		 * @author 	Abdul Ghafor Sabury
		 * @param 	no param	    
	 	*/
		public function create_serial_table(){
	    	$sql_query = "CREATE TABLE IF NOT EXISTS ".$this->tbl_prefix."issmserial (
	            id INT(11) AUTO_INCREMENT PRIMARY KEY, 
	            serial VARCHAR(100) CHARACTER SET utf8 NOT NULL,
	            is_checked tinyint(4) DEFAULT 0,
	            checked_at DATETIME DEFAULT NULL,
	            expired_at DATETIME DEFAULT NULL,
	            is_fake tinyint(4) DEFAULT 0
	          ) $this->charset_collate";
	          require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	          dbDelta($sql_query);
		}


	}


}


?>