<?php 
/**
 * The admin-specific functionality of the plugin.
 *
 * Manipulate database queries
 *
 * @package    iraqsoftserialmanagement
 * @subpackage iraqsoftserialmanagement/includes
 * @author     Abdul Ghafor Sabury <gh.sabury@gmail.com>
 */
if(!class_exists('Issmdatabase')){
	class Issmdatabase{
		/**
		 * hold wpd object
		 *
		 * @since    1.0.0
		 * @access   private
		 * @var      Object
		*/
		private $wpdb_object;

		/**
		 * hold table prefixe
		 *
		 * @since    1.0.0
		 * @access   private
		 * @var      Object
		*/
		public $table_prefix;



		/**
		 * hold name of table for serial
		 *
		 * @since    1.0.0
		 * @access   public
		 * @var      string
		*/
		public $serial_table;

		
		/**
		 * Initialize the class and set its properties.
		 *
		 * @since    1.0.0
		 * @param      no param.
	 	*/
		function __construct(){
			global $wpdb;
			$this->wpdb_object =  $wpdb;
			$this->serial_table = 'issmserial';
			$this->table_prefix = $this->wpdb_object->prefix;
		}



		/**
		 * Select all records.
		 *
		 * @since 	1.0.0
		 * @author 	Abdul Ghafor Sabury
		 * @param 	string, table name
		 * @return  array, selected data 	    
	 	*/
		public function fetch_all_records($tbl_name='', $condition=array()){
			$tbl_name = $this->wpdb_object->prefix . $tbl_name;
			return $this->wpdb_object->get_results($this->wpdb_object->prepare("SELECT * FROM $tbl_name ORDER BY id DESC", $condition));
		}//fetch_all_records



		/**
		 * Insert data.
		 *
		 * @since 	1.0.0
		 * @author 	Abdul Ghafor Sabury
		 * @param 	string, table name
		 * @param 	array, format data
		 * @param 	array, data format
		 * @return  Boolean, true or false 	    
	 	*/
		public function insert_records($tbl_name='', $data= array()){
			$tbl_name = $this->wpdb_object->prefix . $tbl_name;
			return $this->wpdb_object->insert($tbl_name,$data);
		}

		public function checkSerial($serial){
			$table_name = $this->wpdb_object->prefix.'issmserial';
			$query = "SELECT * FROM ".$table_name." WHERE serial= %s  ORDER BY id DESC LIMIT 1";
			$result = $this->wpdb_object->get_results($this->wpdb_object->prepare($query, $serial));
			return $result;
		}

		public function isProductFake($serial){
			$table_name = $this->wpdb_object->prefix.'issmserial';
			$query = "SELECT * FROM ".$table_name." WHERE serial= %s  ORDER BY id DESC LIMIT 1";
			$result = $this->wpdb_object->get_results($this->wpdb_object->prepare($query, $serial));
			return $result[0]->is_fake;
		}


		public function updateProduct($serial,$checked_at, $expired_at){
			$table_name = $this->wpdb_object->prefix.'issmserial';
			
			$query = "SELECT * FROM ".$table_name." WHERE serial= %s  ORDER BY id DESC LIMIT 1";
			$result = $this->wpdb_object->get_results($this->wpdb_object->prepare($query, $serial));
			if($result[0]->checked_at =='' || $result[0]->expired_at==''):
				$query2 = "UPDATE `$table_name` SET `is_checked` = 1, `checked_at`= '".$checked_at."', `expired_at`='".$expired_at."' WHERE `serial` = %s";
				$this->wpdb_object->query($this->wpdb_object->prepare($query2, $serial));
			endif;
		}
		
		public function makeProductFake($serial){
			$table_name = $this->wpdb_object->prefix.'issmserial';
			$query = "UPDATE `$table_name` SET `is_fake` = 1 WHERE `serial` = %s";
			$this->wpdb_object->query($this->wpdb_object->prepare($query, $serial));
		}

		public function fetchExpirationDate($serial){
			$table_name = $this->wpdb_object->prefix.'issmserial';
			$query = "SELECT * FROM ".$table_name." WHERE serial= %s  ORDER BY id DESC LIMIT 1";
			$result = $this->wpdb_object->get_results($this->wpdb_object->prepare($query, $serial));
			return $result[0]->expired_at;
		}


		public function deleteSelectedRows($selected_rows){
			$table_name = $this->wpdb_object->prefix.'issmserial';
			$total_deleted_rows = 0;
			for($i=0; $i<count($selected_rows);  $i++):
				$result = $this->wpdb_object->delete("".$table_name."", array( 'serial'=>$selected_rows[$i]), array('%s'));
				if($result):
					$total_deleted_rows += $result;
				endif;
			endfor;
			echo $total_deleted_rows;
		}
	
	}
}
?>