
 <div class="wrap main-content" style="padding:30px 21px 50px">
        <div class="tablenav top">
            <div class="alignleft actions">
                <h2 class="main_title">Documenation</h2>
               
            </div>
            <br class="clear">
        </div>
        <p class="desc">
        	<b>iraqsoftserialmanagement</b> is a plugin to validate and authenticate the pharmacy products.
        </p>
        <p class="desc">
        	The plugin works base on the shortcuts, so you can use the shortcuts to embed in a page, post or directly in a php file.
        </p>
        	<ul>
        		<li><b>Page or Post:</b> 
        			<code>[autheticateproducts]</code>
        		</li>
        		<li><b>PHP File:</b> 
        			<code>echo do_shortcode( '[autheticateproducts]' );</code>
        		</li>
        	</ul>
        <p>
            <b>Note</b> If you want to import an Excel file with large rows, you must increase Maximum Execution Time on WordPress.
            For exmaple 10,000 needs 15 minuates to be imported.

            <ul>
                <li><b>Method 1: Edit file .htaccess:</b> 
                    <code>php_value max_execution_time 900</code>
                </li>
                <li><b>Method 2: Edit file wp-config.php:</b> 
                    <code>set_time_limit(900);</code>
                </li>

                <li><b>Method 3: Editing php.ini:</b> 
                    <code>max_execution_time = 900</code>
                </li>
            </ul>


        </p>
    </div>