<?php
	function load_serial_page() {
    	require_once (ISSM_BASE_PATH.'includes/class-issm-wpdb.php');

		$db_object = new Issmdatabase();
		$serial_table = $db_object->serial_table;
		$results = $db_object->fetch_all_records($serial_table);
    	require_once("views/index.php");
    }

