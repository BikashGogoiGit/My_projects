$("#scan-qr").click(function(){
	/*$("#preview").show();
	$("#preview").width("100%");*/
	//openNav();

	$("input[name=serial_number]").val("");
  let scanner = new Instascan.Scanner({ video: document.getElementById('preview') });
  scanner.addListener('scan', function (content) {
    $("input[name=serial_number]").val(content);
    /*$("#preview").hide();
    $("#preview").width("0px");*/
    //closeNav();

  });
  Instascan.Camera.getCameras().then(function (cameras) {
    if (cameras.length > 0) {
      scanner.start(cameras[0]);
    } else {
      console.error('No cameras found.');
    }
  }).catch(function (e) {
    console.error(e);
  });
});   

/*$("body").prepend('<div id="myNav" class="overlay">'+
  '<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>'+
  '<div class="overlay-content">'+
    '<video id="preview"></video>'+
  '</div>'+
'</div>');*/

function openNav() {
  document.getElementById("myNav").style.width = "100%";
}

function closeNav() {
  document.getElementById("myNav").style.width = "0%";
}