  // Define base url
  var sub_dir = window.location.origin+window.location.pathname;
  var host_name = window.location.origin;
  sub_dir = sub_dir.replace("/wp-admin/admin.php","");
  sub_dir = sub_dir.replace(host_name,'');
  var base_url = host_name+sub_dir;
  
  // Apply data tbale
  var table = jQuery('.tbl-list').DataTable(
                    {
                        "processing": true,
                        "serverSide": true,
                        "ajax": {
                            "url": base_url+'/wp-admin/admin-ajax.php',
                            "type": "POST",
                            "data" : {action:'load_all_serials_action'},
                        },
                  "columns": [
                      { "data": "serial" },
                      { "data": "is_checked" },
                      { "data": "is_fake" },
                      { "data": "checked_at" },
                      { "data": "expired_at" },

                  ],
                      "order": [],
                     "language": {
                                "paginate": {
                                    "previous": "Prev",
                                    "next": "Next",
                                },
                                "search": "Search ",
                                "zeroRecords": "No result was found",
                                "sLengthMenu": "Show _MENU_ records",
                                "info": "Show  _START_ to _END_ from  _TOTAL_ records",
                            },
                    'lengthMenu': [[20, 25, 50, -1], [20, 25, 50, "All"]],

                  'columnDefs': [{
                           'targets': 5,
                           'searchable': false,
                           'orderable': false,
                           'className': 'dt-body-center',
                           'render': function (data, type, full, meta){
                               return '<input type="checkbox">';
                           }
                        }],

    });

  // Handle click on "Select all" control
   jQuery('#example-select-all').on('click', function(){
      var rows = table.rows({ 'search': 'applied' }).nodes();
      jQuery('input[type="checkbox"]', rows).prop('checked', this.checked);
      if(this.checked){
          jQuery('#delete-row-button').removeAttr('disabled');
      }else{
          jQuery('#delete-row-button').attr('disabled','disabled');
      }
   });
    // Handle click on checkbox to set state of "Select all" control
   jQuery(document).on('change', 'tbody input[type="checkbox"]', function(){
        var total_checked_rows = $('tbody input[type="checkbox"]:checked').length;

        if(total_checked_rows==20){
          jQuery('#example-select-all').attr('checked','checked');
        }else{
          jQuery('#example-select-all').removeAttr('checked');
        }

        if(total_checked_rows>0){
          jQuery('#delete-row-button').removeAttr('disabled');
        }else{
          jQuery('#delete-row-button').attr('disabled','disabled');
        }
   });

   jQuery(document).on('click', '#delete-row-button',function(e){
      var selected_rows = [];
      var counter = 0;
      jQuery('table.dataTable tbody tr td input[type="checkbox"]').each(function(){
            if(this.checked){
              selected_rows[counter] = '<option selected>'+jQuery(this).parent().prev().prev().prev().prev().prev().text()+'</option>' 
              counter++;
            }
      });
      jQuery('#select_rows_dropdown').html(selected_rows);
      jQuery(".delete_modal_dialog").fadeIn();

   });

   // delete button
  jQuery(document).on("click","#delete_records_button", function(){
      jQuery(".delete_modal_dialog .ajax_loader").css({opacity:'1'});
      var select_rows = jQuery('#select_rows_dropdown').val();
      jQuery.ajax({
          url : base_url+'/wp-admin/admin-ajax.php',
          type : 'POST',
          data : {action:'delete_selected_rows_action',select_rows:select_rows},
          success: function(response,status,xhr){
                jQuery(".delete_modal_dialog .ajax_loader").css({opacity:'0'});
                jQuery(".delete_modal_dialog .success_msg").show();
                jQuery('.delete_modal_dialog #total_deleted_records').text(response);
                setTimeout(function(){location.reload();},1000);
            }
      })
      
  }); 



  // Call media uploader
  var mediaUploader;
  jQuery('#import-button-file').click(function(e) {
    e.preventDefault();
    // If the uploader object has already been created, reopen the dialog
    if (mediaUploader){mediaUploader.open();return;}
    // Extend the wp.media object
    mediaUploader = wp.media.frames.file_frame = 
                                                wp.media(
                                                        {
                                                          title: 'Choose Excel File',
                                                          button: {text: 'Choose Excel File'}, 
                                                          multiple: false }
                                                        );

    // When a file is selected, grab the URL and set it as the text field's value
    mediaUploader.on('select', function() {
      var attachment = mediaUploader.state().get('selection').first().toJSON();
      jQuery(".import_modal_dialog").fadeIn();
      jQuery('#imported_excell_file_input').val(attachment.url);
    });
    // Open the uploader dialog
    mediaUploader.open();
  });

 
 // Import from excel file
  jQuery(document).on("click","#import_excell_fille_button", function(){
     var file_path = $("#imported_excell_file_input").val();
     jQuery(".ajax_loader").css({opacity:'1'});
      jQuery.ajax({
          url : base_url+'/wp-admin/admin-ajax.php',
          type : 'POST',
          data : {action:'import_excell_file_action',file_path:file_path},
          success: function(response,status,xhr){
                $(".ajax_loader").css({opacity:'0'});
                if(response==1){
                    $(".import_modal_dialog .success_msg").show();
                }else if(response==0){
                    $(".import_modal_dialog  .warning_msg").show();
                }
                setTimeout(function(){location.reload();},1000);
            }
      })
      
  }); 

  // Load export dialog
  jQuery(document).on("click","#export-button-file", function(e){
     e.preventDefault();
     jQuery('#export_excell_fille_button').show();
     jQuery(".export_modal_dialog").fadeIn();
  }); 
   // Export to excel file
  jQuery(document).on("click","#export_excell_fille_button", function(e){
     e.preventDefault();
     jQuery(".ajax_loader").css({opacity:'1'});
      jQuery.ajax({
          url : base_url+'/wp-admin/admin-ajax.php',
          type : 'POST',
          data : {action:'export_excell_file_action'},
          success: function(response,status,xhr){
               jQuery(".ajax_loader").css({opacity:0});

               jQuery(".export_modal_dialog .success_msg").show();
               jQuery('#download_link').attr('href', response);
               jQuery('#export_excell_fille_button').hide();
            }
      })
      
  }); 


 
  // Close Modal
  jQuery(document).on("click",".diss-messal,.close", function(){
       location.reload();
  })









    

 




