  <img class="img_response"  src="<?php echo ISSM_BASE_URL.'images/original.png'; ?>" width="150">
 <p class="success-msg">Original</p>
  <a href="javascript:void(0)" class="try_again">Authenticate another product</a>