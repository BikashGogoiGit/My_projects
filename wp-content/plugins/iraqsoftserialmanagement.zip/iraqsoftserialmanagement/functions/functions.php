<?php 	

require_once (ISSM_BASE_PATH.'library/import/php-excel-reader/excel_reader2.php');
require_once (ISSM_BASE_PATH.'library/import/SpreadsheetReader.php');

require_once (ISSM_BASE_PATH.'library/datatable/ssp.class.php');

require_once (ISSM_BASE_PATH.'library/export/autoload.php');
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;


/********* Register Menus **********/
add_action('admin_menu','issm_create_menu');
function issm_create_menu() {
	global $serial_page;
	global $documentation_page;
	
	// Serial page
	$serial_page = add_menu_page(
								'Serials',
								'Serials',
								'manage_options',
								'serials',
								'load_serial_page',
								'dashicons-admin-multisite',
								80);
	
	//Documentation Page
	$documentation_page = add_submenu_page(
									'serials',
									'Documentation',
									'Documentation',
									'manage_options',
									'documentation',
									'load_documentation_page');

	

}
	
	/**
	 * Enqueue styles
	 *
	 * @since 	1.0.0
	 * @author 	Abdul Ghafor Sabury    
	*/
	
	add_action( 'admin_enqueue_scripts', 'issm_load_styles' );
	function issm_load_styles($hook){
			require ISSM_BASE_PATH . 'includes/where-to-load-js-css-files.php';
			$resource_object->load_styles($hook);
	}

	


	/**
	 * Enqueue scripts
	 *
	 * @since 	1.0.0
	 * @author 	Abdul Ghafor Sabury
	 * @param 	string, menu bame
	 * @return  no return type 	    
		*/
		
		add_action( 'admin_enqueue_scripts', 'issm_load_scripts');
		function issm_load_scripts($hook){
				require ISSM_BASE_PATH . 'includes/where-to-load-js-css-files.php';
				$resource_object->load_scripts($hook);
		}
		



/******call Media Uploader******/
add_action("admin_enqueue_scripts", "issm_enqueue_media_uploader");
function issm_enqueue_media_uploader(){wp_enqueue_media();}


// Include wpdb file	
require_once (ISSM_BASE_PATH.'includes/class-issm-wpdb.php');
$db_object = new Issmdatabase();




add_action('wp_ajax_import_excell_file_action', 'import_excell_file');
add_action('wp_ajax_nopriv_import_excell_file_action', 'import_excell_file');
function import_excell_file() {
			$full_path = $_POST['file_path'];
			$str = explode('/',$full_path);
        	$str_name = $str[count($str)-1];
        	$str_month = $str[count($str)-2];
        	$str_year = $str[count($str)-3];
        	$file_path = ISSM_BASE_PATH.$str_year.'/'.$str_month.'/'.$str_name;
        	$file_path = str_replace('plugins', 'uploads', $file_path);
        	$file_path = str_replace('iraqsoftserialmanagement', '', $file_path);

        	if(is_readable($file_path)):
                $Reader = new SpreadsheetReader($file_path);
                $totalSheet = count($Reader->sheets());

                for($i=0;$i<$totalSheet;$i++){
                    $Reader->ChangeSheet($i);
                    foreach ($Reader as $Row){

                    		$form_data = array();
							global $db_object;
							$tbl_name = $db_object->serial_table;
							
							if(isset($Row[0])):
								$form_data['serial'] = $Row[0];
							endif;
							
							/*
							if(isset($Row[1])):
								$form_data['is_checked'] = $Row[1];
							endif;

							if(isset($Row[2])):
								 	$checked_at = explode('-', $Row[2]);
									$form_data['checked_at'] = date('Y').'-'.$checked_at[1].'-'.$checked_at[0];
							endif;

							if(isset($Row[3])):
								$expired_at = explode('-', $Row[3]);
								$form_data['expired_at'] = date('Y').'-'.$expired_at[1].'-'.$expired_at[0];
							endif;

							if(isset($Row[4])):
								$form_data['is_fake'] = $Row[4];
							endif;
							*/
							if(empty($db_object->checkSerial($form_data['serial']))){
								$db_object->insert_records($tbl_name,$form_data);
							}
                    } 
                }
               
                echo 1;
            else:
                echo 0;
            endif;
  		exit; 
	}



add_action('wp_ajax_export_excell_file_action', 'export_excell_file');
add_action('wp_ajax_nopriv_export_excell_file_action', 'export_excell_file');
function export_excell_file() {
			$file_path = str_replace('plugins', '', ISSM_ABSPATH);
			$file_path = str_replace('\iraqsoftserialmanagement/', '', $file_path);
			$file_path = $file_path.'uploads';
			
			$spreadsheet = new Spreadsheet();
			
			$sheet = $spreadsheet->getActiveSheet();



			global $db_object;
			$tbl_name = $db_object->serial_table;
			$results = $db_object->fetch_all_records($tbl_name);
			
			$sheet->setTitle('sheet1');
			$sheet->getColumnDimension('A')->setAutoSize(true);
			$sheet->getColumnDimension('B')->setAutoSize(true);
			$sheet->getColumnDimension('C')->setAutoSize(true);
			$sheet->getColumnDimension('D')->setAutoSize(true);
			$sheet->getColumnDimension('E')->setAutoSize(true);

			
			$counter= 1;
			foreach ($results as $result):
				$sheet->setCellValue('A'.$counter.'', ''.$result->serial.'');
				$sheet->setCellValue('B'.$counter.'', ''.$result->is_checked.'');
				$sheet->setCellValue('C'.$counter.'', ''.$result->checked_at.'');
				$sheet->setCellValue('D'.$counter.'', ''.$result->expired_at.'');
				$sheet->setCellValue('E'.$counter.'', ''.$result->is_fake.'');
				$counter++;
			endforeach;
			$file_name = 'serial-list';
			$filepath = $file_path.'/'.$file_name.'.xlsx';
			$writer = new Xlsx($spreadsheet);
			$writer->save($filepath);
			echo site_url().'/wp-content/uploads/'.$file_name.'.xlsx';
  		exit; 
	}


add_action('wp_ajax_load_all_serials_action', 'load_all_serials');
add_action('wp_ajax_nopriv_load_all_serials_action', 'load_all_serials');
function load_all_serials() {
			global $db_object;
			$table = $db_object->serial_table;
			$table = $db_object->table_prefix.''.$table;
			$primaryKey = 'id';
			
			$columns = array(
    			array( 'db' => 'serial', 'dt' => 'serial' ),
    			array( 'db' => 'is_checked', 'dt' => 'is_checked' ),
    			array( 'db' => 'is_fake', 'dt' => 'is_fake' ),
    			array( 'db' => 'checked_at', 'dt' => 'checked_at' ),
    			array( 'db' => 'expired_at', 'dt' => 'expired_at' ),
    		);
			
			$sql_details = array(
			    'user' => DB_USER,
			    'pass' => DB_PASSWORD,
			    'db'   => DB_NAME,
			    'host' => DB_HOST
			);

			echo json_encode(
    			SSP::simple( $_POST, $sql_details, $table, $primaryKey, $columns )
			);
  		exit; 
	}


add_action('wp_ajax_delete_selected_rows_action', 'delete_selected_rows');
add_action('wp_ajax_nopriv_delete_selected_rows_action', 'delete_selected_rows');
function delete_selected_rows() {
			global $db_object;
			$table = $db_object->serial_table;
			$table = $db_object->table_prefix.''.$table;
			$select_rows = $_POST['select_rows'];
			echo $db_object->deleteSelectedRows($select_rows);
  		exit; 
	}













