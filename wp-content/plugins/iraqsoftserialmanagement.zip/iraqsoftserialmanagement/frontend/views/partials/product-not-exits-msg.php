 <img class="img_response"  src="<?php echo ISSM_BASE_URL.'images/notexists.png'; ?>" width="150">
  <p class="error-msg">Not Found</p>
 <a href="javascript:void(0)" class="try_again">Authenticate another product</a>