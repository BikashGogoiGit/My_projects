var full_path = window.location.origin+window.location.pathname;
var base_url = undefined;
if(full_path.search('http://localhost')==-1){
    base_url = window.location.origin;
}else{
  full_path = full_path.split("/");
  base_url = window.location.origin+'/'+full_path[3];
}



  jQuery(document).on("click","#authentication_btn", function(e){
      e.preventDefault()
       var serial_number = jQuery("input[name='serial_number']").val();
       var vefication_code = jQuery("input[name='vefication_code']").val();
       var vcode = jQuery("#vcode").text();
       var loader = jQuery(".issm_container img.ajx_loader");
       var result = jQuery(".issm_container .result-cont");
       if(serial_number==''){
          jQuery("input[name='serial_number']").prev().show(900).find('.error_generated').text('This field is Required');
       }else if(vefication_code==''){
          jQuery("input[name='vefication_code']").prev().show(900).find('.error_generated').text('This field is Required');
       }else if(vefication_code!= vcode){
          jQuery("input[name='vefication_code']").prev().show(900).find('.error_generated').text('The above code is Wrong')
       }else{
            loader.show();
          jQuery.ajax({
              url : base_url+'/wp-admin/admin-ajax.php',
              type : 'POST',
              data : {action:'authentication_action',serial_number:serial_number, vefication_code:vefication_code},
              success: function(response,status,xhr){
                    loader.hide();
                    result.html(response);
                }
          });
       }  
    }); 
  setInterval(function() {
          jQuery("input[name='serial_number']").prev().hide().find('.error_generated').text('');
          jQuery("input[name='vefication_code']").prev().hide().find('.error_generated').text('');
  }, 3000);


  jQuery(document).on('click','.issm_container a.try_again', function(){
      window.location.reload();
  })
   


jQuery(document).on("click",".issm_container form .formgroup span", function(e){
          jQuery.ajax({
              url : base_url+'/wp-admin/admin-ajax.php',
              type : 'POST',
              data : {action:'generate_new_code_action'},
              success: function(response,status,xhr){
                    jQuery('.issm_container form .formgroup span').text(response);
                }
          }); 
    }); 










    

 




