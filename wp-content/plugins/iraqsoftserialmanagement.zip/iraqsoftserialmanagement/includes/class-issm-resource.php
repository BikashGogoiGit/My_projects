<?php 
/**
 *
 * Loads all resources, resources are css and js files
 *
 * @package    iraqsoftserialmanagement
 * @subpackage iraqsoftserialmanagement/includes
 * @author     Abdul Ghafor Sabury <gh.sabury@gmail.com>
 */

if(!class_exists('Issmresource')){
	
	class Issmresource{

		/**
		 * holds name of serial page 
		 *
		 * @since    1.0.0
		 * @access   public
		 * @var      string
		*/
		public $serial_page;
		/**
		 * holds name of semester documentation page
		 *
		 * @since    1.0.0
		 * @access   public
		 * @var      string
		*/
		public $documentation_page;

		/**
		 * Initialize the class and set its properties.
		 *
		 * @since    1.0.0
		 * @param     array
	 	*/

		function __construct($menu = array()){
			$this->serial_page = $menu['serial'];
			$this->documentation_page = $menu['documentation'];
		}

		/**
		 * Enqueue styles to the header
		 *
		 * @since 	1.0.0
		 * @author 	Abdul Ghafor Sabury
		 * @param 	string, hook
		 * @return  void 	    
	 	*/
	 	public function load_styles($hook){
			if($hook != $this->serial_page && $hook!=$this->documentation_page)return;
			wp_enqueue_style('issm_data_table_style',ISSM_BASE_URL."css/jquery.dataTables.min.css",array(),'4.7.0','all');
			// wp_enqueue_style('issm_fontawesoome_style',ISSM_BASE_URL."css/font-awesome.css",array(),'4.7.0','all');
			wp_enqueue_style('issm_custom_style',ISSM_BASE_URL."css/style.css",array(),'1.0','all');
	 	}

	 	/**
		 * Enqueue js files to the footer
		 *
		 * @since 	1.0.0
		 * @author 	Abdul Ghafor Sabury
		 * @param 	string, hook
		 * @return  void 	    
	 	*/
	public function load_scripts($hook='') {
				if($hook != $this->serial_page && $hook!=$this->documentation_page)return;
		   		wp_enqueue_script('issm_data_table_script',ISSM_BASE_URL."js/jquery.dataTables.min.js",array(),'3.3.1',true);
		   		wp_enqueue_script('issm_custom_script',ISSM_BASE_URL."js/custom.js",array(),'1.0',true);
		}

	}
}

?>