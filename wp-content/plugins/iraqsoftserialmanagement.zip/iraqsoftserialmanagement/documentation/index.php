<?php
	function load_documentation_page() {
    	require_once("views/index.php");
    }

