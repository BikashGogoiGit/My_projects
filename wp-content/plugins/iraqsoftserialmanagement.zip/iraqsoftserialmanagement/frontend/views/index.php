<div class="issm_container">
    <div class="result-cont">
	   <form method="post">
            
            <video id="preview"></video>

            <div class="formgroup serial-input">
                <div class="error-message">
                    <i class="error_generated"></i>
                    <b class="arrow"></b>
                </div>
                <input type="text" name="serial_number" placeholder="Enter Serial Number">
            </div>

            <div class="formgroup">
                <button type="button" id="scan-qr">Scan QR Code</button>
            </div>

            <div class="formgroup">
                 <span id="vcode"><?php echo mt_rand(100000, 999999); ?></span>
            </div>

            <div class="formgroup code-input">
                <div class="error-message">
                    <i class="error_generated"></i>
                    <b class="arrow"></b>
                </div>
                <input type="text" name="vefication_code" placeholder="Enter Code Shown Above">
            </div>

            <div class="formgroup" style="margin-bottom: 0;">
                    <img class="ajx_loader" src="<?php echo ISSM_BASE_URL.'images/ajax-loader.gif'; ?>">
            </div>

            <div class="formgroup">
				<button type="button" id="authentication_btn">Authenticate</button>
            </div>
	   </form>


    
    </div>
</div>

