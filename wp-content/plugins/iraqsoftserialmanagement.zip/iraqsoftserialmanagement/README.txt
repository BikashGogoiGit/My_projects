=== iraqsoftserialmanagement ===
Contributors: no contributors
Donate link: Its commercial, so does not need to be donated.
Tags: Iraq Soft, IraqSoft, Iraq, Serial Management, Pharamcy Management
Requires at least: 3.0.1
Tested up to: 5.2.4
Stable tag: 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

iraqsoftserialmanagement is WordPress plugin for authenticating and validating the medical products.

== Long Description ==
iraqsoftserialmanagement is WordPress plugin for authenticating and validating the medical products.
It can be installed in any WordPress theme.



== Installation ==
1. Upload iraqsoftserialmanagement to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. A new section will be add the menu and find it.
4. You are done!!


== Frequently Asked Questions ==
 1. Can it be installed in any WordPress theme?
 Yes


== Fetures ==
1. Import from Excel file
2. Export to Excel file
3. Display list of products
4. Validating and authenticating pharmacy products