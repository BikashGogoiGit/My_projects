
 <div class="wrap main-content" style="padding:30px 21px 50px">
        <div class="tablenav top">
            <div class="alignleft actions">
                <a 
                    href="#"
                    class="button-primary"
                    id="import-button-file"
                    style="margin-bottom:10px">Import as file</a> 

                 <a 
                    href="#"
                    class="button-primary"
                    id="export-button-file"
                    style="margin-bottom:10px">Export file</a>

                 <button 
                    class="button-primary"
                    disabled 
                    id="delete-row-button"
                    style="margin-bottom:10px">Delete</button>

            </div>
            <br class="clear">
        </div>
        <table 
            class='wp-list-table widefat fixed striped posts table tbl-list dataTable' 
            style="width:100%" id="dataTable">
            <thead>
                <tr>
                    <th class="manage-column ss-list-width">Serial</th>
                    <th class="manage-column ss-list-width">Is Checked</th>
                    <th class="manage-column ss-list-width">Is Fake</th>
                    <th class="manage-column ss-list-width">Checked At</th>
                    <th class="manage-column ss-list-width">Expired At</th>
                    <th class="manage-column ss-list-width">
                        <input type="checkbox" name="select_all" value="1" id="example-select-all" style="margin-left:0">
                    </th>
                </tr>
            </thead>
        </table>
    </div>

    
    <div class="modal-conainter modal_dialog import_modal_dialog">
            <div class="content">
                <div class="modal-header">
                        <h1>Are you sure to import the Excel file?</h1>
                        <span class="diss-messal" aria-hidden="true">X</span>
                </div>
                <div class="modal-content">
                        <img 
                            src="<?php echo ISSM_BASE_URL ?>/images/ajax-loader.gif"
                            class="ajax_loader">
                        <p class="msg success_msg">Done!</p>
                        <p class="msg warning_msg">Sorry an error occured during importing, please try once again!</p>
                        <input 
                            type="hidden"
                            id="imported_excell_file_input">
                                
                                <button 
                                    class="button-primary confirm" 
                                    id="import_excell_fille_button">Yes</button>
                                
                                <button class="button-danger close">Cancel</button>
                </div>
            </div>
    </div>


    <div class="modal-conainter modal_dialog export_modal_dialog">
            <div class="content">
                <div class="modal-header">
                        <h1>Are you sure to export data to Excel file?</h1>
                        <span class="diss-messal" aria-hidden="true">X</span>
                </div>
                <div class="modal-content">
                        <img 
                            src="<?php echo ISSM_BASE_URL ?>/images/ajax-loader.gif"
                            class="ajax_loader">
                            <p class="msg success_msg">Done! &nbsp;<a href="#" id="download_link">Download</a></p>
                        <input 
                            type="hidden"
                            id="imported_excell_file_input">
                                
                                <button 
                                    class="button-primary confirm" 
                                    id="export_excell_fille_button">Yes</button>
                                
                                <button class="button-danger close">Cancel</button>
                </div>
            </div>
    </div>


     <div class="modal-conainter modal_dialog delete_modal_dialog">
            <div class="content">
                <div class="modal-header">
                        <h1>Are you sure to delete the selected records?</h1>
                        <span class="diss-messal" aria-hidden="true">X</span>
                </div>
                <div class="modal-content">
                        <img 
                            src="<?php echo ISSM_BASE_URL ?>/images/ajax-loader.gif"
                            class="ajax_loader">
                            <p class="msg success_msg"><span id=total_deleted_records></span> rows deleted successfully</p>
                            <select name="records[]" id="select_rows_dropdown" multiple style="display:none;"></select>
                                <button 
                                    class="button-primary confirm" 
                                    id="delete_records_button">Yes</button>
                                <button class="button-danger close">Cancel</button>
                </div>
            </div>
    </div>


    