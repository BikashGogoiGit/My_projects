<?php
	// Include wpdb file	
	require_once (ISSM_BASE_PATH.'includes/class-issm-wpdb.php');
	$db_object = new Issmdatabase();

	// load styles
	add_action( 'wp_enqueue_scripts', 'issm_load_frontend_styles');
	function issm_load_frontend_styles(){
		wp_enqueue_style('issm_front_style',ISSM_BASE_URL.'css/front-style.css');
		wp_enqueue_style('issm_qr_scanner_style',ISSM_BASE_URL.'css/qr-scanner.css');
	}

	// Load scripts
	add_action( 'wp_enqueue_scripts', 'issm_load_frontend_scripts');
	function issm_load_frontend_scripts(){
		wp_enqueue_script('issm_jquery_core','https://code.jquery.com/jquery-3.4.1.min.js',array(),'',footer);
		wp_enqueue_script('issm_front_js',ISSM_BASE_URL.'js/front-js.js',array('issm_jquery_core'),'',footer);

		//rbg
		wp_enqueue_script('issm_instascan','https://rawgit.com/schmich/instascan-builds/master/instascan.min.js',array(),'',footer);
		wp_enqueue_script('issm_qr_scanner_js',ISSM_BASE_URL.'js/qr-scanner.js',array('issm_jquery_core'),'',footer);
		//wp_enqueue_script('issm_instascan','https://raw.githubusercontent.com/mebjas/html5-qrcode/master/minified/html5-qrcode.min.js',array(),'',footer);
		//wp_enqueue_script('issm_instascan','https://unpkg.com/html5-qrcode/minified/html5-qrcode.min.js',array(),'',footer);
	}


	function issm_shortcode() {
			ob_start();
			require_once(ISSM_BASE_PATH.'frontend/views/index.php');
			return ob_get_clean(); 	
	}
	add_shortcode( 'autheticateproducts', 'issm_shortcode' );



add_action('wp_ajax_authentication_action', 'authentication');
add_action('wp_ajax_nopriv_authentication_action', 'authentication');
function authentication() {
		$serial_number = trim($_POST['serial_number']);
		$vefication_code = trim($_POST['vefication_code']);

		global $db_object;
		$result = $db_object->checkSerial($serial_number);
		if(count($result)==1):
			if($db_object->isProductFake($serial_number)):
				require_once (ISSM_BASE_PATH.'frontend/views/partials/fake-product-msg.php');
			else:
				$current_time = current_time('Y-m-d H:i:s');
				$expiration_from_db = strtotime($db_object->fetchExpirationDate($serial_number));
				if(strtotime($current_time)>$expiration_from_db && $expiration_from_db!=''){
						$db_object->makeProductFake($serial_number);
						require_once (ISSM_BASE_PATH.'frontend/views/partials/fake-product-msg.php');
				}else{	
						$expiration_date = date('Y-m-d H:i:s', strtotime($current_time . ' +1 day'));
    					$db_object->updateProduct($serial_number,$current_time, $expiration_date);
    					require_once (ISSM_BASE_PATH.'frontend/views/partials/original-product-msg.php'); 
				}
			endif;
		else:
			require_once (ISSM_BASE_PATH.'frontend/views/partials/product-not-exits-msg.php');
		endif;

	 exit; 
}

add_action('wp_ajax_generate_new_code_action', 'generate_new_code');
add_action('wp_ajax_nopriv_generate_new_code_action', 'generate_new_code');
function generate_new_code() {
		echo mt_rand(100000, 999999);
	 exit; 
}


?>