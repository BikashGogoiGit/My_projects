<?php
	// include resource class for loading css and js files
	require_once(ISSM_BASE_PATH . 'includes/class-issm-resource.php');
	global $serial_page;
	global $documentation_page;
	$menu = array('documentation'=>$documentation_page, 'serial'=>$serial_page);
	$resource_object = new Issmresource($menu);

 ?>