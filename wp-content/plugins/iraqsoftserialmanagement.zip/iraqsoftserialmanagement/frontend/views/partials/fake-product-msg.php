  <img class="img_response"  src="<?php echo ISSM_BASE_URL.'images/fake.png'; ?>" width="150">
 <p class="error-msg">Fake</p>
  <a href="javascript:void(0)" class="try_again">Authenticate another product</a>