<?php
/**

 * @link              https://www.iraq-soft.com/iraqsoftserialmanagement/
 * @since             1.0.0
 * @package           iraqsoftserialmanagement
 *
 * @wordpress-plugin
 * Plugin Name:       iraqsoftserialmanagement
 * Plugin URI:         https://www.iraq-soft.com/iraqsoftserialmanagement/
 * Description:       Authenticating and validating the medical products
 * Version:           1.0.0
 * Author:            Iraqsoft
 * Author URI:        https://www.iraq-soft.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       iraqsoftserialmanagement
 * Domain Path:       /iraqsoftserialmanagement
 */



// Define constant to fetch plugin base url for including php files
if(!defined('ISSM_BASE_PATH')){
		define('ISSM_BASE_PATH', plugin_dir_path(__FILE__));
}

// Define constant to fetch plugin base url for including js and css files
if(!defined('ISSM_BASE_URL')){
		define('ISSM_BASE_URL', plugin_dir_url(__FILE__));
}

if ( !defined('ISSM_ABSPATH') ){
    define('ISSM_ABSPATH', dirname(__FILE__) . '/');
}

/************Create all tables ************/	    
register_activation_hook(__FILE__, 'issm_create_tables');

function issm_create_tables(){				
	require_once(ISSM_BASE_PATH . 'includes/class-issm-migration.php');
	$migration = new Issmmigration();
	$migration->create_serial_table();
}

/************ Functions ************/
require_once(ISSM_BASE_PATH.'functions/functions.php');

/************ Serial Page **********/
 require_once(ISSM_BASE_PATH . 'serial/index.php');

/************Documentation Page ************/
 require_once(ISSM_BASE_PATH . 'documentation/index.php');
 


require_once(ISSM_BASE_PATH.'frontend/index.php');
	
	
	

?>